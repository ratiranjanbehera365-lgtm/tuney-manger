package com.tuneymanger.app

import com.google.gson.Gson
import com.tuneymanger.app.data.backup.TuneyBackupPayload
import com.tuneymanger.app.data.database.entities.AccountEntity
import com.tuneymanger.app.data.database.entities.TransactionEntity
import com.tuneymanger.app.util.CurrencyFormatter
import org.junit.Assert.*
import org.junit.Test

class AccountingLogicTest {

    @Test
    fun testIndianNumberFormatting() {
        assertEquals("1,00,000", CurrencyFormatter.formatIndianNumber(100000L))
        assertEquals("1,25,000", CurrencyFormatter.formatIndianNumber(125000L))
        assertEquals("1,23,45,678", CurrencyFormatter.formatIndianNumber(12345678L))
        assertEquals("500", CurrencyFormatter.formatIndianNumber(500L))
    }

    @Test
    fun testPaiseToInrFormatting() {
        assertEquals("₹1,25,000.00", CurrencyFormatter.formatPaiseToInr(12500000L))
        assertEquals("₹100.50", CurrencyFormatter.formatPaiseToInr(10050L))
        assertEquals("-₹50.00", CurrencyFormatter.formatPaiseToInr(-5000L))
    }

    @Test
    fun testInputParsingToPaise() {
        assertEquals(12500000L, CurrencyFormatter.parseInputToPaise("1,25,000"))
        assertEquals(10050L, CurrencyFormatter.parseInputToPaise("₹100.50"))
        assertEquals(50000L, CurrencyFormatter.parseInputToPaise("500.00"))
    }

    @Test
    fun testIncomeCalculation() {
        val initialBalancePaise = 500000L
        val incomeAmountPaise = 250000L
        val finalBalancePaise = initialBalancePaise + incomeAmountPaise
        assertEquals(750000L, finalBalancePaise)
    }

    @Test
    fun testExpenseCalculation() {
        val initialBalancePaise = 1000000L
        val expenseAmountPaise = 320000L
        val finalBalancePaise = initialBalancePaise - expenseAmountPaise
        assertEquals(680000L, finalBalancePaise)
    }

    @Test
    fun testTransferBetweenAccountsDoesNotAffectTotalNetWorth() {
        val sourceInitial = 1000000L
        val destInitial = 200000L
        val initialTotal = sourceInitial + destInitial

        val transferAmount = 400000L
        val sourceFinal = sourceInitial - transferAmount
        val destFinal = destInitial + transferAmount
        val finalTotal = sourceFinal + destFinal

        assertEquals(600000L, sourceFinal)
        assertEquals(600000L, destFinal)
        assertEquals(initialTotal, finalTotal)
    }

    @Test
    fun testTransactionEditReversalAccounting() {
        var accountBalance = 1000000L
        val oldExpense = 200000L
        accountBalance -= oldExpense

        val newExpense = 350000L
        accountBalance += oldExpense
        accountBalance -= newExpense

        assertEquals(650000L, accountBalance)
    }

    @Test
    fun testUdharLendingAndPartialRepayment() {
        var accountBalance = 1000000L
        val principalLent = 500000L
        var outstandingReceivable = principalLent

        accountBalance -= principalLent
        assertEquals(500000L, accountBalance)
        assertEquals(500000L, outstandingReceivable)

        val partialRepayment1 = 200000L
        outstandingReceivable -= partialRepayment1
        accountBalance += partialRepayment1
        assertEquals(300000L, outstandingReceivable)
        assertEquals(700000L, accountBalance)

        val partialRepayment2 = 300000L
        outstandingReceivable -= partialRepayment2
        accountBalance += partialRepayment2
        assertEquals(0L, outstandingReceivable)
        assertEquals(1000000L, accountBalance)
    }

    @Test
    fun testUdharBorrowingAndRepayment() {
        var accountBalance = 500000L
        val principalBorrowed = 400000L
        var outstandingPayable = principalBorrowed

        accountBalance += principalBorrowed
        assertEquals(900000L, accountBalance)
        assertEquals(400000L, outstandingPayable)

        val repayment = 400000L
        outstandingPayable -= repayment
        accountBalance -= repayment
        assertEquals(0L, outstandingPayable)
        assertEquals(500000L, accountBalance)
    }

    @Test
    fun testInvestmentValuationAndProfitLoss() {
        val quantity = 10.0
        val purchasePricePaise = 50000L
        val totalInvestedPaise = (quantity * purchasePricePaise).toLong()

        val currentPricePaise = 65000L
        val currentValuationPaise = (quantity * currentPricePaise).toLong()
        val unrealizedGainPaise = currentValuationPaise - totalInvestedPaise

        assertEquals(500000L, totalInvestedPaise)
        assertEquals(650000L, currentValuationPaise)
        assertEquals(150000L, unrealizedGainPaise)

        val unitsSold = 4.0
        val sellPricePaise = 65000L
        val proceedsPaise = (unitsSold * sellPricePaise).toLong()
        val costBasis = (unitsSold * purchasePricePaise).toLong()
        val realizedGainPaise = proceedsPaise - costBasis

        assertEquals(60000L, realizedGainPaise)
    }

    @Test
    fun testBudgetUsageCalculation() {
        val budgetLimitPaise = 2500000L
        val currentExpensePaise = 2000000L
        val remainingPaise = budgetLimitPaise - currentExpensePaise
        val percentageUsed = ((currentExpensePaise.toDouble() / budgetLimitPaise.toDouble()) * 100).toInt()

        assertEquals(500000L, remainingPaise)
        assertEquals(80, percentageUsed)
    }

    @Test
    fun testBackupSerializationAndDeserialization() {
        val payload = TuneyBackupPayload(
            schemaVersion = 1,
            appName = "Tuney Manger",
            appVersion = "1.0.0",
            exportedAtTimestamp = 1700000000000L,
            accounts = listOf(
                AccountEntity(id = 1, name = "Cash", type = "CASH", openingBalancePaise = 500000, currentBalancePaise = 500000)
            ),
            transactions = listOf(
                TransactionEntity(
                    id = 1,
                    type = "EXPENSE",
                    amountPaise = 15000,
                    accountId = 1,
                    categoryName = "Food and Grocery",
                    dateTimestamp = 1700000000000L,
                    description = "Grocery run"
                )
            )
        )

        val gson = Gson()
        val json = gson.toJson(payload)
        assertNotNull(json)
        assertTrue(json.contains("Tuney Manger"))
        assertTrue(json.contains("Food and Grocery"))

        val deserialized = gson.fromJson(json, TuneyBackupPayload::class.java)
        assertEquals(1, deserialized.schemaVersion)
        assertEquals(1, deserialized.accounts.size)
        assertEquals("Cash", deserialized.accounts[0].name)
        assertEquals(1, deserialized.transactions.size)
        assertEquals(15000L, deserialized.transactions[0].amountPaise)
    }
}
