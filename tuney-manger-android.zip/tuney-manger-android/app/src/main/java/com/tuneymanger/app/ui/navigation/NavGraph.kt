package com.tuneymanger.app.ui.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.*
import com.tuneymanger.app.ui.components.AddTransactionDialog
import com.tuneymanger.app.ui.screens.*
import com.tuneymanger.app.ui.viewmodel.FinanceViewModel

@Composable
fun MainNavigationGraph(viewModel: FinanceViewModel) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    var showGlobalAddTxDialog by remember { mutableStateOf(false) }
    val accounts by viewModel.activeAccounts.collectAsState()
    val categories by viewModel.allCategories.collectAsState()

    val isBottomBarVisible = bottomNavScreens.any { it.route == currentRoute }

    Scaffold(
        bottomBar = {
            if (isBottomBarVisible) {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = NavigationBarDefaults.Elevation
                ) {
                    bottomNavScreens.forEach { screen ->
                        NavigationBarItem(
                            icon = { screen.icon?.let { Icon(it, contentDescription = screen.title) } },
                            label = { Text(screen.title) },
                            selected = currentRoute == screen.route,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(navController.graph.findStartDestination().id) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.Home.route) {
                DashboardScreen(
                    viewModel = viewModel,
                    navController = navController,
                    onAddTransactionClick = { showGlobalAddTxDialog = true }
                )
            }
            composable(Screen.Transactions.route) {
                TransactionsScreen(
                    viewModel = viewModel,
                    onOpenAddDialog = { showGlobalAddTxDialog = true }
                )
            }
            composable(Screen.Investments.route) {
                InvestmentsScreen(viewModel = viewModel)
            }
            composable(Screen.Udhar.route) {
                UdharScreen(viewModel = viewModel)
            }
            composable(Screen.More.route) {
                MoreScreen(navController = navController)
            }
            composable(Screen.Accounts.route) {
                AccountsScreen(viewModel = viewModel)
            }
            composable(Screen.Budgets.route) {
                BudgetsScreen(viewModel = viewModel)
            }
            composable(Screen.SavingsGoals.route) {
                SavingsGoalsScreen(viewModel = viewModel)
            }
            composable(Screen.Reports.route) {
                ReportsScreen(viewModel = viewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(viewModel = viewModel, navController = navController)
            }
            composable(Screen.BackupRestore.route) {
                BackupRestoreScreen(viewModel = viewModel)
            }
        }
    }

    if (showGlobalAddTxDialog) {
        AddTransactionDialog(
            accounts = accounts,
            categories = categories,
            onDismiss = { showGlobalAddTxDialog = false },
            onConfirm = { type, amountPaise, accId, destAccId, catId, catName, date, method, desc, notes ->
                viewModel.addTransaction(
                    type = type,
                    amountPaise = amountPaise,
                    accountId = accId,
                    destinationAccountId = destAccId,
                    categoryId = catId,
                    categoryName = catName,
                    dateTimestamp = date,
                    paymentMethod = method,
                    description = desc,
                    payee = null,
                    notes = notes
                )
                showGlobalAddTxDialog = false
            }
        )
    }
}
