package com.tuneymanger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuneymanger.app.data.database.entities.InvestmentEntity
import com.tuneymanger.app.ui.components.EmptyState
import com.tuneymanger.app.ui.viewmodel.FinanceViewModel
import com.tuneymanger.app.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun InvestmentsScreen(viewModel: FinanceViewModel) {
    val investments by viewModel.investments.collectAsState()
    val totalInvested by viewModel.totalInvestedPaise.collectAsState()
    val totalValuation by viewModel.totalPortfolioValuationPaise.collectAsState()
    val totalRealized by viewModel.totalRealizedProfitLossPaise.collectAsState()
    val accounts by viewModel.activeAccounts.collectAsState()

    val unrealizedGainPaise = totalValuation - totalInvested

    var showAddDialog by remember { mutableStateOf(false) }
    var selectedForValuation by remember { mutableStateOf<InvestmentEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Investments & Wealth", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("Add Investment") }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text("Estimated Portfolio Valuation", style = MaterialTheme.typography.bodyMedium)
                        Text(
                            text = CurrencyFormatter.formatPaiseToInr(totalValuation),
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Total Invested", style = MaterialTheme.typography.labelSmall)
                                Text(
                                    CurrencyFormatter.formatPaiseToInr(totalInvested),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Column {
                                Text("Unrealized P/L", style = MaterialTheme.typography.labelSmall)
                                val gainColor = if (unrealizedGainPaise >= 0) Color(0xFF10B981) else Color(0xFFEF4444)
                                Text(
                                    CurrencyFormatter.formatPaiseToInr(unrealizedGainPaise),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = gainColor
                                )
                            }
                            Column {
                                Text("Realized P/L", style = MaterialTheme.typography.labelSmall)
                                val realColor = if (totalRealized >= 0) Color(0xFF10B981) else Color(0xFFEF4444)
                                Text(
                                    CurrencyFormatter.formatPaiseToInr(totalRealized),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = realColor
                                )
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "* Prices are manually updated for offline privacy. No third-party tracking.",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (investments.isEmpty()) {
                item {
                    EmptyState(message = "No investments recorded yet")
                }
            } else {
                items(investments, key = { it.id }) { inv ->
                    InvestmentCard(
                        investment = inv,
                        onUpdatePrice = { selectedForValuation = inv }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    if (showAddDialog) {
        AddInvestmentDialog(
            accounts = accounts,
            onDismiss = { showAddDialog = false },
            onConfirm = { name, category, qty, pricePaise, investedPaise, broker, accId ->
                viewModel.addInvestment(name, category, qty, pricePaise, investedPaise, broker, accId)
                showAddDialog = false
            }
        )
    }

    selectedForValuation?.let { inv ->
        UpdateValuationDialog(
            investment = inv,
            onDismiss = { selectedForValuation = null },
            onConfirm = { newPricePaise ->
                viewModel.updateInvestmentPrice(inv.id, newPricePaise)
                selectedForValuation = null
            }
        )
    }
}

@Composable
fun InvestmentCard(investment: InvestmentEntity, onUpdatePrice: () -> Unit) {
    val gain = investment.currentValuationPaise - investment.totalInvestedPaise
    val gainColor = if (gain >= 0) Color(0xFF10B981) else Color(0xFFEF4444)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text(investment.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "${investment.category} • ${investment.quantity} units",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        CurrencyFormatter.formatPaiseToInr(investment.currentValuationPaise),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "${if (gain >= 0) "+" else ""}${CurrencyFormatter.formatPaiseToInr(gain)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = gainColor,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                OutlinedButton(onClick = onUpdatePrice, shape = RoundedCornerShape(8.dp)) {
                    Text("Update Valuation", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
fun AddInvestmentDialog(
    accounts: List<com.tuneymanger.app.data.database.entities.AccountEntity>,
    onDismiss: () -> Unit,
    onConfirm: (name: String, category: String, qty: Double, pricePaise: Long, totalInvestedPaise: Long, broker: String?, accId: Long?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("MUTUAL_FUNDS") }
    var qtyInput by remember { mutableStateOf("1.0") }
    var priceInput by remember { mutableStateOf("") }
    var broker by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Investment") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Asset / Scheme Name *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = qtyInput, onValueChange = { qtyInput = it }, label = { Text("Quantity / Units *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = priceInput, onValueChange = { priceInput = it }, label = { Text("Price per Unit (₹) *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = broker, onValueChange = { broker = it }, label = { Text("Broker / Platform") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val pricePaise = CurrencyFormatter.parseInputToPaise(priceInput)
                    val qty = qtyInput.toDoubleOrNull() ?: 1.0
                    val totalInvested = (qty * pricePaise).toLong()
                    if (name.isNotBlank() && pricePaise > 0) {
                        onConfirm(name.trim(), category, qty, pricePaise, totalInvested, broker.ifBlank { null }, null)
                    }
                },
                enabled = name.isNotBlank() && priceInput.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun UpdateValuationDialog(
    investment: InvestmentEntity,
    onDismiss: () -> Unit,
    onConfirm: (newPricePaise: Long) -> Unit
) {
    var priceInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Update Current Price") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(investment.name, fontWeight = FontWeight.Bold)
                OutlinedTextField(
                    value = priceInput,
                    onValueChange = { priceInput = it },
                    label = { Text("Latest Price per Unit (₹)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paise = CurrencyFormatter.parseInputToPaise(priceInput)
                    if (paise > 0) onConfirm(paise)
                },
                enabled = priceInput.isNotBlank()
            ) {
                Text("Update")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
