package com.tuneymanger.app.data.database.dao

import androidx.room.*
import com.tuneymanger.app.data.database.entities.SavingsContributionEntity
import com.tuneymanger.app.data.database.entities.SavingsGoalEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface SavingsGoalDao {
    @Query("SELECT * FROM savings_goals WHERE status != 'ARCHIVED' ORDER BY createdAt DESC")
    fun getAllActiveGoals(): Flow<List<SavingsGoalEntity>>

    @Query("SELECT * FROM savings_goals ORDER BY createdAt DESC")
    fun getAllGoals(): Flow<List<SavingsGoalEntity>>

    @Query("SELECT * FROM savings_goals WHERE id = :id LIMIT 1")
    suspend fun getGoalById(id: Long): SavingsGoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: SavingsGoalEntity): Long

    @Update
    suspend fun updateGoal(goal: SavingsGoalEntity)

    @Query("UPDATE savings_goals SET currentSavedPaise = currentSavedPaise + :deltaPaise WHERE id = :goalId")
    suspend fun updateSavedAmount(goalId: Long, deltaPaise: Long)

    @Delete
    suspend fun deleteGoal(goal: SavingsGoalEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertContribution(contribution: SavingsContributionEntity): Long

    @Query("SELECT * FROM savings_contributions WHERE goalId = :goalId ORDER BY dateTimestamp DESC")
    fun getContributionsForGoal(goalId: Long): Flow<List<SavingsContributionEntity>>

    @Delete
    suspend fun deleteContribution(contribution: SavingsContributionEntity)
}
