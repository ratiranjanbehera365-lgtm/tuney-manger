package com.tuneymanger.app.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(val route: String, val title: String, val icon: ImageVector? = null) {
    object Home : Screen("home", "Home", Icons.Default.Home)
    object Transactions : Screen("transactions", "Transactions", Icons.Default.ReceiptLong)
    object Investments : Screen("investments", "Investments", Icons.Default.TrendingUp)
    object Udhar : Screen("udhar", "Udhar", Icons.Default.People)
    object More : Screen("more", "More", Icons.Default.Menu)

    object Accounts : Screen("accounts", "Accounts", Icons.Default.AccountBalance)
    object Budgets : Screen("budgets", "Budgets", Icons.Default.PieChart)
    object SavingsGoals : Screen("savings_goals", "Savings Goals", Icons.Default.Savings)
    object Reports : Screen("reports", "Reports & Analytics", Icons.Default.BarChart)
    object Settings : Screen("settings", "Settings", Icons.Default.Settings)
    object BackupRestore : Screen("backup_restore", "Backup & Restore", Icons.Default.CloudSync)
}

val bottomNavScreens = listOf(
    Screen.Home,
    Screen.Transactions,
    Screen.Investments,
    Screen.Udhar,
    Screen.More
)
