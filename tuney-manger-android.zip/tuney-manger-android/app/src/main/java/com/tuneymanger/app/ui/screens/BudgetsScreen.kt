package com.tuneymanger.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuneymanger.app.ui.components.EmptyState
import com.tuneymanger.app.ui.viewmodel.FinanceViewModel
import com.tuneymanger.app.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetsScreen(viewModel: FinanceViewModel) {
    val budget by viewModel.currentOverallBudget.collectAsState()
    val monthlyExpense by viewModel.currentMonthExpensePaise.collectAsState()
    var showSetBudgetDialog by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Monthly Budget", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showSetBudgetDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Edit, contentDescription = null) },
                text = { Text(if (budget == null) "Set Budget" else "Edit Budget") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            if (budget == null) {
                EmptyState(
                    message = "No budget set for this month",
                    hint = "Set an overall monthly spending limit to prevent overspending"
                )
            } else {
                val limit = budget!!.limitPaise
                val spent = monthlyExpense
                val remaining = Math.max(0L, limit - spent)
                val percent = if (limit > 0) ((spent.toDouble() / limit.toDouble()) * 100).toInt() else 0
                val isOver = spent > limit

                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Monthly Spending Limit", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "$percent%",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = if (isOver) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        LinearProgressIndicator(
                            progress = { (percent / 100f).coerceIn(0f, 1f) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(12.dp)
                                .clip(CircleShape),
                            color = if (isOver) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary
                        )

                        Spacer(modifier = Modifier.height(16.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Column {
                                Text("Budget Limit", style = MaterialTheme.typography.labelSmall)
                                Text(CurrencyFormatter.formatPaiseToInr(limit), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text("Total Spent", style = MaterialTheme.typography.labelSmall)
                                Text(CurrencyFormatter.formatPaiseToInr(spent), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                            }
                            Column {
                                Text(if (isOver) "Over Budget By" else "Remaining", style = MaterialTheme.typography.labelSmall)
                                val remAmount = if (isOver) (spent - limit) else remaining
                                Text(
                                    CurrencyFormatter.formatPaiseToInr(remAmount),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isOver) MaterialTheme.colorScheme.error else Color(0xFF10B981)
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showSetBudgetDialog) {
        var input by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showSetBudgetDialog = false },
            title = { Text("Set Monthly Budget Limit") },
            text = {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    label = { Text("Budget in Rupees (₹) *") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        val paise = CurrencyFormatter.parseInputToPaise(input)
                        if (paise > 0) {
                            viewModel.setOverallMonthlyBudget(paise)
                            showSetBudgetDialog = false
                        }
                    },
                    enabled = input.isNotBlank()
                ) {
                    Text("Save")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSetBudgetDialog = false }) { Text("Cancel") }
            }
        )
    }
}
