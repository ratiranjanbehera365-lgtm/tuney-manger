package com.tuneymanger.app.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "investments")
data class InvestmentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val category: String, // STOCKS, MUTUAL_FUNDS, ETFS, GOLD, FIXED_DEPOSIT, RECURRING_DEPOSIT, BONDS, CRYPTO, OTHER
    val quantity: Double = 0.0,
    val totalInvestedPaise: Long = 0L,
    val currentPricePaise: Long = 0L,
    val currentValuationPaise: Long = 0L,
    val realizedProfitLossPaise: Long = 0L,
    val brokerOrProvider: String? = null,
    val notes: String? = null,
    val lastValuationDate: Long = System.currentTimeMillis(),
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "investment_transactions",
    foreignKeys = [
        ForeignKey(
            entity = InvestmentEntity::class,
            parentColumns = ["id"],
            childColumns = ["investmentId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("investmentId"), Index("accountId")]
)
data class InvestmentTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val investmentId: Long,
    val type: String, // BUY, SELL, VALUATION_UPDATE
    val units: Double = 0.0,
    val pricePerUnitPaise: Long = 0L,
    val totalAmountPaise: Long = 0L,
    val realizedGainLossPaise: Long = 0L,
    val accountId: Long? = null,
    val dateTimestamp: Long = System.currentTimeMillis(),
    val notes: String? = null
)
