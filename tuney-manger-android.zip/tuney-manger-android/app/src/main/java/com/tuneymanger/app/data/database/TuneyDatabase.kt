package com.tuneymanger.app.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.tuneymanger.app.data.database.dao.*
import com.tuneymanger.app.data.database.entities.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        AccountEntity::class,
        TransactionEntity::class,
        CategoryEntity::class,
        BudgetEntity::class,
        SavingsGoalEntity::class,
        SavingsContributionEntity::class,
        InvestmentEntity::class,
        InvestmentTransactionEntity::class,
        UdharPersonEntity::class,
        UdharLoanEntity::class,
        UdharRepaymentEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class TuneyDatabase : RoomDatabase() {

    abstract fun accountDao(): AccountDao
    abstract fun transactionDao(): TransactionDao
    abstract fun categoryDao(): CategoryDao
    abstract fun budgetDao(): BudgetDao
    abstract fun savingsGoalDao(): SavingsGoalDao
    abstract fun investmentDao(): InvestmentDao
    abstract fun udharDao(): UdharDao

    companion object {
        @Volatile
        private var INSTANCE: TuneyDatabase? = null

        fun getDatabase(context: Context, scope: CoroutineScope): TuneyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    TuneyDatabase::class.java,
                    "tuney_manger.db"
                )
                    .addCallback(DatabaseCallback(scope))
                    .build()
                INSTANCE = instance
                instance
            }
        }

        private class DatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database)
                    }
                }
            }

            private suspend fun populateInitialData(database: TuneyDatabase) {
                val categoryDao = database.categoryDao()
                val accountDao = database.accountDao()

                // Default accounts
                accountDao.insertAccount(
                    AccountEntity(
                        name = "Cash",
                        type = "CASH",
                        openingBalancePaise = 0L,
                        currentBalancePaise = 0L,
                        colorHex = "#10B981"
                    )
                )
                accountDao.insertAccount(
                    AccountEntity(
                        name = "Main Bank Account",
                        type = "SAVINGS_BANK",
                        openingBalancePaise = 0L,
                        currentBalancePaise = 0L,
                        colorHex = "#3B82F6"
                    )
                )

                // Default Expense Categories
                val defaultExpenses = listOf(
                    "Food and Grocery" to "#10B981",
                    "Rent" to "#EF4444",
                    "Petrol and Fuel" to "#F59E0B",
                    "Transport" to "#6366F1",
                    "Medicine and Healthcare" to "#EC4899",
                    "Electricity and Utilities" to "#EAB308",
                    "Mobile and Internet" to "#06B6D4",
                    "Shopping" to "#8B5CF6",
                    "Education" to "#3B82F6",
                    "Travel" to "#14B8A6",
                    "Entertainment" to "#F97316",
                    "EMI and Loan Payments" to "#DC2626",
                    "Family" to "#84CC16",
                    "Personal Care" to "#D946EF",
                    "Insurance" to "#475569",
                    "Other" to "#6B7280"
                ).map { (name, color) ->
                    CategoryEntity(
                        name = name,
                        type = "EXPENSE",
                        colorHex = color,
                        isDefault = true
                    )
                }

                // Default Income Categories
                val defaultIncomes = listOf(
                    "Salary" to "#10B981",
                    "Business Income" to "#3B82F6",
                    "Commission" to "#8B5CF6",
                    "Interest" to "#F59E0B",
                    "Investment Income" to "#14B8A6",
                    "Refund" to "#06B6D4",
                    "Other Income" to "#6B7280"
                ).map { (name, color) ->
                    CategoryEntity(
                        name = name,
                        type = "INCOME",
                        colorHex = color,
                        isDefault = true
                    )
                }

                categoryDao.insertDefaultCategories(defaultExpenses)
                categoryDao.insertDefaultCategories(defaultIncomes)
            }
        }
    }
}
