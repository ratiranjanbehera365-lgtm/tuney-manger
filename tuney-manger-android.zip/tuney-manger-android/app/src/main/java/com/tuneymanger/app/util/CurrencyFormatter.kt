package com.tuneymanger.app.util

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Utility for Indian numbering format (lakhs & crores) and financial calculations.
 * All monetary amounts in Room entities are stored in integer Paise (1 Rupee = 100 Paise).
 */
object CurrencyFormatter {

    fun formatPaiseToInr(paise: Long, showDecimals: Boolean = true): String {
        val isNegative = paise < 0
        val absPaise = Math.abs(paise)
        val rupees = absPaise / 100
        val remainingPaise = absPaise % 100

        val formattedRupees = formatIndianNumber(rupees)
        val prefix = if (isNegative) "-₹" else "₹"
        return if (showDecimals) {
            String.format(Locale.ENGLISH, "%s%s.%02d", prefix, formattedRupees, remainingPaise)
        } else {
            "$prefix$formattedRupees"
        }
    }

    fun formatIndianNumber(number: Long): String {
        val s = number.toString()
        if (s.length <= 3) return s

        val lastThree = s.substring(s.length - 3)
        val rest = s.substring(0, s.length - 3)

        val sb = StringBuilder()
        var count = 0
        for (i in rest.length - 1 downTo 0) {
            sb.append(rest[i])
            count++
            if (count % 2 == 0 && i > 0) {
                sb.append(',')
            }
        }
        val formattedRest = sb.reverse().toString()
        return "$formattedRest,$lastThree"
    }

    fun parseInputToPaise(input: String): Long {
        val sanitized = input.replace("₹", "").replace(",", "").trim()
        if (sanitized.isBlank()) return 0L
        return try {
            val d = sanitized.toDouble()
            (d * 100.0 + 0.5).toLong()
        } catch (e: Exception) {
            0L
        }
    }

    fun formatDate(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatDateTime(timestamp: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formatMonthYear(timestamp: Long): String {
        val sdf = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
