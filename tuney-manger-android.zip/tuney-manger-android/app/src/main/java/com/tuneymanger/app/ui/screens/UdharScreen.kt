package com.tuneymanger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tuneymanger.app.data.database.entities.AccountEntity
import com.tuneymanger.app.data.database.entities.UdharLoanEntity
import com.tuneymanger.app.data.database.entities.UdharPersonEntity
import com.tuneymanger.app.ui.components.EmptyState
import com.tuneymanger.app.ui.components.sendWhatsAppReminder
import com.tuneymanger.app.ui.viewmodel.FinanceViewModel
import com.tuneymanger.app.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UdharScreen(
    viewModel: FinanceViewModel
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }

    val allLoans by viewModel.udharLoans.collectAsState()
    val persons by viewModel.udharPersons.collectAsState()
    val accounts by viewModel.activeAccounts.collectAsState()

    val totalReceivable by viewModel.totalReceivablePaise.collectAsState()
    val totalPayable by viewModel.totalPayablePaise.collectAsState()

    val filteredLoans = remember(allLoans, selectedTab) {
        val targetType = if (selectedTab == 0) "LENT" else "BORROWED"
        allLoans.filter { it.type == targetType }
    }

    var showAddPersonDialog by remember { mutableStateOf(false) }
    var showCreateLoanDialog by remember { mutableStateOf(false) }
    var loanToRepay by remember { mutableStateOf<UdharLoanEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Udhar Manager", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
                actions = {
                    IconButton(onClick = { showAddPersonDialog = true }) {
                        Icon(Icons.Default.PersonAdd, contentDescription = "Add Contact")
                    }
                }
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showCreateLoanDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text(if (selectedTab == 0) "Lend Money" else "Borrow Money") }
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
        ) {
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = MaterialTheme.colorScheme.surfaceVariant,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Money Lent", fontWeight = FontWeight.Bold)
                            Text(
                                CurrencyFormatter.formatPaiseToInr(totalReceivable),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF10B981)
                            )
                        }
                    }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("Money Borrowed", fontWeight = FontWeight.Bold)
                            Text(
                                CurrencyFormatter.formatPaiseToInr(totalPayable),
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFEF4444)
                            )
                        }
                    }
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            if (filteredLoans.isEmpty()) {
                val label = if (selectedTab == 0) "No money lent records yet" else "No money borrowed records yet"
                EmptyState(message = label)
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredLoans, key = { it.id }) { loan ->
                        val person = persons.find { it.id == loan.personId }
                        UdharLoanCard(
                            loan = loan,
                            person = person,
                            onRepayClick = { loanToRepay = loan },
                            onWhatsAppClick = {
                                person?.let { p ->
                                    sendWhatsAppReminder(context, p.phoneNumber, p.name, loan.outstandingPaise)
                                }
                            },
                            onDeleteClick = { viewModel.deleteLoan(loan.id) }
                        )
                    }
                    item {
                        Spacer(modifier = Modifier.height(80.dp))
                    }
                }
            }
        }
    }

    if (showAddPersonDialog) {
        AddPersonDialog(
            onDismiss = { showAddPersonDialog = false },
            onConfirm = { name, phone, relation ->
                viewModel.addUdharPerson(name, phone, relation, null)
                showAddPersonDialog = false
            }
        )
    }

    if (showCreateLoanDialog) {
        CreateLoanDialog(
            type = if (selectedTab == 0) "LENT" else "BORROWED",
            persons = persons,
            accounts = accounts,
            onDismiss = { showCreateLoanDialog = false },
            onConfirm = { personId, amountPaise, date, dueDate, accountId, desc ->
                viewModel.createUdharLoan(personId, if (selectedTab == 0) "LENT" else "BORROWED", amountPaise, date, dueDate, accountId, desc)
                showCreateLoanDialog = false
            },
            onAddPersonClick = {
                showCreateLoanDialog = false
                showAddPersonDialog = true
            }
        )
    }

    loanToRepay?.let { loan ->
        val person = persons.find { it.id == loan.personId }
        RecordRepaymentDialog(
            loan = loan,
            personName = person?.name ?: "Contact",
            accounts = accounts,
            onDismiss = { loanToRepay = null },
            onConfirm = { amountPaise, accountId, notes ->
                viewModel.recordUdharRepayment(loan.id, amountPaise, accountId, notes)
                loanToRepay = null
            }
        )
    }
}

@Composable
fun UdharLoanCard(
    loan: UdharLoanEntity,
    person: UdharPersonEntity?,
    onRepayClick: () -> Unit,
    onWhatsAppClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    val isLent = loan.type == "LENT"
    val isOverdue = loan.status == "OVERDUE"
    val isSettled = loan.status == "FULLY_REPAID"

    val statusColor = when {
        isSettled -> Color(0xFF10B981)
        isOverdue -> Color(0xFFEF4444)
        else -> Color(0xFFF59E0B)
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = person?.name ?: "Unknown Contact",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    if (!person?.relationship.isNullOrBlank()) {
                        Text(text = person!!.relationship!!, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = statusColor.copy(alpha = 0.15f)
                ) {
                    Text(
                        text = loan.status.replace("_", " "),
                        style = MaterialTheme.typography.labelSmall,
                        color = statusColor,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("Original Principal", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        CurrencyFormatter.formatPaiseToInr(loan.principalPaise),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Outstanding Balance", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        CurrencyFormatter.formatPaiseToInr(loan.outstandingPaise),
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isLent) Color(0xFF10B981) else Color(0xFFEF4444)
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "${loan.description} • Given: ${CurrencyFormatter.formatDate(loan.dateTimestamp)}",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (loan.dueDateTimestamp != null) {
                Text(
                    text = "Due Date: ${CurrencyFormatter.formatDate(loan.dueDateTimestamp)}",
                    style = MaterialTheme.typography.bodySmall,
                    color = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.Medium
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                if (isLent && !isSettled) {
                    Button(
                        onClick = onWhatsAppClick,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("WhatsApp Reminder", fontSize = 12.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                }

                if (!isSettled) {
                    OutlinedButton(
                        onClick = onRepayClick,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Record Repayment", fontSize = 12.sp)
                    }
                }

                IconButton(onClick = onDeleteClick) {
                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
fun AddPersonDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, phone: String?, relation: String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var relation by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Udhar Contact") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Full Name *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("Mobile Number (for WhatsApp reminders)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = relation,
                    onValueChange = { relation = it },
                    label = { Text("Relationship / Tag (Friend, Colleague, Vendor)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { if (name.isNotBlank()) onConfirm(name.trim(), phone, relation) },
                enabled = name.isNotBlank()
            ) {
                Text("Save Contact")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun CreateLoanDialog(
    type: String,
    persons: List<UdharPersonEntity>,
    accounts: List<AccountEntity>,
    onDismiss: () -> Unit,
    onConfirm: (personId: Long, amountPaise: Long, date: Long, dueDate: Long?, accountId: Long?, desc: String) -> Unit,
    onAddPersonClick: () -> Unit
) {
    var selectedPersonIndex by remember { mutableIntStateOf(0) }
    var amountInput by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedAccountIndex by remember { mutableIntStateOf(0) }
    var linkAccount by remember { mutableStateOf(accounts.isNotEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (type == "LENT") "Record Money Lent" else "Record Money Borrowed") },
        text = {
            if (persons.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No contacts found. Please add a contact first.")
                    Spacer(modifier = Modifier.height(12.dp))
                    Button(onClick = onAddPersonClick) { Text("Add Contact") }
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Select Person: ${persons.getOrNull(selectedPersonIndex)?.name ?: ""}", fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(
                        value = amountInput,
                        onValueChange = { amountInput = it },
                        label = { Text("Principal Amount (₹) *") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Reason / Description *") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (accounts.isNotEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = linkAccount, onCheckedChange = { linkAccount = it })
                            Text(
                                if (type == "LENT") "Deduct from account" else "Add to account",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            if (persons.isNotEmpty()) {
                Button(
                    onClick = {
                        val paise = CurrencyFormatter.parseInputToPaise(amountInput)
                        if (paise > 0 && description.isNotBlank()) {
                            val accId = if (linkAccount && accounts.isNotEmpty()) accounts[selectedAccountIndex].id else null
                            onConfirm(persons[selectedPersonIndex].id, paise, System.currentTimeMillis(), null, accId, description.trim())
                        }
                    },
                    enabled = amountInput.isNotBlank() && description.isNotBlank()
                ) {
                    Text("Record")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun RecordRepaymentDialog(
    loan: UdharLoanEntity,
    personName: String,
    accounts: List<AccountEntity>,
    onDismiss: () -> Unit,
    onConfirm: (amountPaise: Long, accountId: Long?, notes: String?) -> Unit
) {
    var amountInput by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var selectedAccIndex by remember { mutableIntStateOf(0) }
    var linkAccount by remember { mutableStateOf(accounts.isNotEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Record Repayment") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Contact: $personName", fontWeight = FontWeight.Bold)
                Text(
                    "Outstanding: ${CurrencyFormatter.formatPaiseToInr(loan.outstandingPaise)}",
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Repayment Amount (₹) *") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paise = CurrencyFormatter.parseInputToPaise(amountInput)
                    if (paise > 0 && paise <= loan.outstandingPaise) {
                        val accId = if (linkAccount && accounts.isNotEmpty()) accounts[selectedAccIndex].id else null
                        onConfirm(paise, accId, notes.trim().ifBlank { null })
                    }
                },
                enabled = amountInput.isNotBlank()
            ) {
                Text("Save Repayment")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
