package com.tuneymanger.app.data.repository

import androidx.room.withTransaction
import com.tuneymanger.app.data.database.TuneyDatabase
import com.tuneymanger.app.data.database.dao.CategorySpendingSummary
import com.tuneymanger.app.data.database.entities.*
import kotlinx.coroutines.flow.Flow

class FinanceRepository(private val database: TuneyDatabase) {

    private val accountDao = database.accountDao()
    private val transactionDao = database.transactionDao()
    private val categoryDao = database.categoryDao()
    private val budgetDao = database.budgetDao()
    private val savingsGoalDao = database.savingsGoalDao()
    private val investmentDao = database.investmentDao()
    private val udharDao = database.udharDao()

    // ACCOUNTS
    fun getAllActiveAccounts(): Flow<List<AccountEntity>> = accountDao.getAllActiveAccounts()
    fun getAllAccounts(): Flow<List<AccountEntity>> = accountDao.getAllAccounts()
    fun getAccountFlowById(id: Long): Flow<AccountEntity?> = accountDao.getAccountFlowById(id)
    suspend fun getAccountById(id: Long): AccountEntity? = accountDao.getAccountById(id)

    suspend fun createAccount(
        name: String,
        type: String,
        openingBalancePaise: Long,
        bankName: String? = null,
        lastFourDigits: String? = null,
        colorHex: String = "#10B981"
    ): Long {
        val account = AccountEntity(
            name = name,
            type = type,
            openingBalancePaise = openingBalancePaise,
            currentBalancePaise = openingBalancePaise,
            bankName = bankName,
            lastFourDigits = lastFourDigits,
            colorHex = colorHex
        )
        return accountDao.insertAccount(account)
    }

    suspend fun updateAccount(account: AccountEntity) {
        accountDao.updateAccount(account)
    }

    suspend fun archiveAccount(accountId: Long) {
        accountDao.archiveAccount(accountId)
    }

    suspend fun deleteAccountSafe(account: AccountEntity): Boolean {
        val txCount = accountDao.getTransactionCountForAccount(account.id)
        return if (txCount > 0) {
            accountDao.archiveAccount(account.id)
            false
        } else {
            accountDao.deleteAccount(account)
            true
        }
    }

    // TRANSACTIONS
    fun getAllTransactions(): Flow<List<TransactionEntity>> = transactionDao.getAllTransactions()
    fun getRecentTransactions(limit: Int = 10): Flow<List<TransactionEntity>> = transactionDao.getRecentTransactions(limit)
    fun getTransactionsInRange(startMs: Long, endMs: Long): Flow<List<TransactionEntity>> = transactionDao.getTransactionsInRange(startMs, endMs)
    fun getTransactionsForAccount(accountId: Long): Flow<List<TransactionEntity>> = transactionDao.getTransactionsForAccount(accountId)

    fun getTotalIncomePaiseInRange(startMs: Long, endMs: Long): Flow<Long?> = transactionDao.getTotalIncomePaiseInRange(startMs, endMs)
    fun getTotalExpensePaiseInRange(startMs: Long, endMs: Long): Flow<Long?> = transactionDao.getTotalExpensePaiseInRange(startMs, endMs)
    fun getCategoryExpenseSummary(startMs: Long, endMs: Long): Flow<List<CategorySpendingSummary>> = transactionDao.getCategoryExpenseSummary(startMs, endMs)

    suspend fun createTransaction(transaction: TransactionEntity): Long {
        require(transaction.amountPaise > 0) { "Transaction amount must be strictly positive" }
        return database.withTransaction {
            when (transaction.type) {
                "INCOME" -> {
                    accountDao.updateBalance(transaction.accountId, transaction.amountPaise)
                }
                "EXPENSE" -> {
                    accountDao.updateBalance(transaction.accountId, -transaction.amountPaise)
                }
                "TRANSFER" -> {
                    requireNotNull(transaction.destinationAccountId) { "Destination account required for transfer" }
                    require(transaction.accountId != transaction.destinationAccountId) { "Source and destination cannot be identical" }
                    accountDao.updateBalance(transaction.accountId, -transaction.amountPaise)
                    accountDao.updateBalance(transaction.destinationAccountId, transaction.amountPaise)
                }
            }
            transactionDao.insertTransaction(transaction)
        }
    }

    suspend fun updateTransaction(newTx: TransactionEntity) {
        require(newTx.amountPaise > 0) { "Transaction amount must be strictly positive" }
        database.withTransaction {
            val oldTx = transactionDao.getTransactionById(newTx.id) ?: return@withTransaction

            when (oldTx.type) {
                "INCOME" -> accountDao.updateBalance(oldTx.accountId, -oldTx.amountPaise)
                "EXPENSE" -> accountDao.updateBalance(oldTx.accountId, oldTx.amountPaise)
                "TRANSFER" -> {
                    oldTx.destinationAccountId?.let { destId ->
                        accountDao.updateBalance(oldTx.accountId, oldTx.amountPaise)
                        accountDao.updateBalance(destId, -oldTx.amountPaise)
                    }
                }
            }

            when (newTx.type) {
                "INCOME" -> accountDao.updateBalance(newTx.accountId, newTx.amountPaise)
                "EXPENSE" -> accountDao.updateBalance(newTx.accountId, -newTx.amountPaise)
                "TRANSFER" -> {
                    requireNotNull(newTx.destinationAccountId) { "Destination account required for transfer" }
                    require(newTx.accountId != newTx.destinationAccountId) { "Source and destination cannot be identical" }
                    accountDao.updateBalance(newTx.accountId, -newTx.amountPaise)
                    accountDao.updateBalance(newTx.destinationAccountId, newTx.amountPaise)
                }
            }

            transactionDao.updateTransaction(newTx)
        }
    }

    suspend fun deleteTransaction(transactionId: Long) {
        database.withTransaction {
            val tx = transactionDao.getTransactionById(transactionId) ?: return@withTransaction
            when (tx.type) {
                "INCOME" -> accountDao.updateBalance(tx.accountId, -tx.amountPaise)
                "EXPENSE" -> accountDao.updateBalance(tx.accountId, tx.amountPaise)
                "TRANSFER" -> {
                    tx.destinationAccountId?.let { destId ->
                        accountDao.updateBalance(tx.accountId, tx.amountPaise)
                        accountDao.updateBalance(destId, -tx.amountPaise)
                    }
                }
            }
            transactionDao.deleteTransaction(tx)
        }
    }

    // CATEGORIES
    fun getAllCategories(): Flow<List<CategoryEntity>> = categoryDao.getAllCategories()
    fun getCategoriesByType(type: String): Flow<List<CategoryEntity>> = categoryDao.getCategoriesByType(type)
    suspend fun insertCategory(category: CategoryEntity): Long = categoryDao.insertCategory(category)
    suspend fun updateCategory(category: CategoryEntity) = categoryDao.updateCategory(category)
    suspend fun deleteCategory(category: CategoryEntity) = categoryDao.deleteCategory(category)

    // BUDGETS
    fun getBudgetsForMonth(yearMonth: String): Flow<List<BudgetEntity>> = budgetDao.getBudgetsForMonth(yearMonth)
    fun getOverallBudgetForMonth(yearMonth: String): Flow<BudgetEntity?> = budgetDao.getOverallBudgetForMonth(yearMonth)
    suspend fun setBudget(budget: BudgetEntity): Long = budgetDao.insertOrUpdateBudget(budget)
    suspend fun deleteBudget(budget: BudgetEntity) = budgetDao.deleteBudget(budget)

    // SAVINGS GOALS
    fun getAllActiveGoals(): Flow<List<SavingsGoalEntity>> = savingsGoalDao.getAllActiveGoals()
    fun getAllGoals(): Flow<List<SavingsGoalEntity>> = savingsGoalDao.getAllGoals()
    suspend fun insertGoal(goal: SavingsGoalEntity): Long = savingsGoalDao.insertGoal(goal)
    suspend fun updateGoal(goal: SavingsGoalEntity) = savingsGoalDao.updateGoal(goal)
    suspend fun deleteGoal(goal: SavingsGoalEntity) = savingsGoalDao.deleteGoal(goal)

    suspend fun addSavingsContribution(goalId: Long, accountId: Long?, amountPaise: Long, notes: String?): Long {
        require(amountPaise != 0L) { "Contribution amount cannot be zero" }
        return database.withTransaction {
            accountId?.let { accId ->
                accountDao.updateBalance(accId, -amountPaise)
            }
            savingsGoalDao.updateSavedAmount(goalId, amountPaise)
            val contrib = SavingsContributionEntity(
                goalId = goalId,
                accountId = accountId,
                amountPaise = amountPaise,
                notes = notes
            )
            savingsGoalDao.insertContribution(contrib)
        }
    }

    fun getContributionsForGoal(goalId: Long): Flow<List<SavingsContributionEntity>> = savingsGoalDao.getContributionsForGoal(goalId)

    // INVESTMENTS
    fun getAllInvestments(): Flow<List<InvestmentEntity>> = investmentDao.getAllInvestments()
    fun getTotalInvestedPaise(): Flow<Long?> = investmentDao.getTotalInvestedPaise()
    fun getTotalPortfolioValuationPaise(): Flow<Long?> = investmentDao.getTotalPortfolioValuationPaise()
    fun getTotalRealizedProfitLossPaise(): Flow<Long?> = investmentDao.getTotalRealizedProfitLossPaise()

    suspend fun addInvestment(
        name: String,
        category: String,
        quantity: Double,
        purchasePricePaise: Long,
        totalInvestedPaise: Long,
        brokerOrProvider: String?,
        notes: String?,
        linkedAccountId: Long?
    ): Long {
        return database.withTransaction {
            linkedAccountId?.let { accId ->
                accountDao.updateBalance(accId, -totalInvestedPaise)
            }
            val investment = InvestmentEntity(
                name = name,
                category = category,
                quantity = quantity,
                totalInvestedPaise = totalInvestedPaise,
                currentPricePaise = purchasePricePaise,
                currentValuationPaise = totalInvestedPaise,
                brokerOrProvider = brokerOrProvider,
                notes = notes
            )
            val invId = investmentDao.insertInvestment(investment)
            val tx = InvestmentTransactionEntity(
                investmentId = invId,
                type = "BUY",
                units = quantity,
                pricePerUnitPaise = purchasePricePaise,
                totalAmountPaise = totalInvestedPaise,
                accountId = linkedAccountId,
                notes = "Initial purchase"
            )
            investmentDao.insertInvestmentTransaction(tx)
            invId
        }
    }

    suspend fun updateInvestmentValuation(investmentId: Long, newPricePerUnitPaise: Long) {
        database.withTransaction {
            val inv = investmentDao.getInvestmentById(investmentId) ?: return@withTransaction
            val newValuation = if (inv.quantity > 0.0) {
                (inv.quantity * newPricePerUnitPaise).toLong()
            } else {
                newPricePerUnitPaise
            }
            val updated = inv.copy(
                currentPricePaise = newPricePerUnitPaise,
                currentValuationPaise = newValuation,
                lastValuationDate = System.currentTimeMillis()
            )
            investmentDao.updateInvestment(updated)
        }
    }

    suspend fun sellInvestment(
        investmentId: Long,
        unitsToSell: Double,
        sellingPricePerUnitPaise: Long,
        receivingAccountId: Long?,
        notes: String?
    ) {
        database.withTransaction {
            val inv = investmentDao.getInvestmentById(investmentId) ?: return@withTransaction
            val totalProceeds = (unitsToSell * sellingPricePerUnitPaise).toLong()
            val costBasisPerUnit = if (inv.quantity > 0.0) (inv.totalInvestedPaise / inv.quantity) else 0.0
            val costOfSoldUnits = (unitsToSell * costBasisPerUnit).toLong()
            val realizedGain = totalProceeds - costOfSoldUnits

            val remainingUnits = Math.max(0.0, inv.quantity - unitsToSell)
            val remainingInvested = Math.max(0L, inv.totalInvestedPaise - costOfSoldUnits)
            val remainingValuation = (remainingUnits * sellingPricePerUnitPaise).toLong()

            receivingAccountId?.let { accId ->
                accountDao.updateBalance(accId, totalProceeds)
            }

            val updatedInv = inv.copy(
                quantity = remainingUnits,
                totalInvestedPaise = remainingInvested,
                currentValuationPaise = remainingValuation,
                realizedProfitLossPaise = inv.realizedProfitLossPaise + realizedGain,
                lastValuationDate = System.currentTimeMillis()
            )
            investmentDao.updateInvestment(updatedInv)

            val tx = InvestmentTransactionEntity(
                investmentId = investmentId,
                type = "SELL",
                units = unitsToSell,
                pricePerUnitPaise = sellingPricePerUnitPaise,
                totalAmountPaise = totalProceeds,
                realizedGainLossPaise = realizedGain,
                accountId = receivingAccountId,
                notes = notes
            )
            investmentDao.insertInvestmentTransaction(tx)
        }
    }

    // UDHAR MANAGER
    fun getAllPersons(): Flow<List<UdharPersonEntity>> = udharDao.getAllPersons()
    suspend fun insertPerson(name: String, phone: String?, relation: String?, notes: String?): Long {
        val person = UdharPersonEntity(
            name = name.trim(),
            phoneNumber = phone?.trim()?.ifBlank { null },
            relationship = relation?.trim()?.ifBlank { null },
            notes = notes?.trim()?.ifBlank { null }
        )
        return udharDao.insertPerson(person)
    }

    fun getAllLoans(): Flow<List<UdharLoanEntity>> = udharDao.getAllLoans()
    fun getLoansByType(type: String): Flow<List<UdharLoanEntity>> = udharDao.getLoansByType(type)
    fun getLoansForPerson(personId: Long): Flow<List<UdharLoanEntity>> = udharDao.getLoansForPerson(personId)
    fun getTotalReceivablePaise(): Flow<Long?> = udharDao.getTotalReceivablePaise()
    fun getTotalPayablePaise(): Flow<Long?> = udharDao.getTotalPayablePaise()
    fun getRepaymentsForLoan(loanId: Long): Flow<List<UdharRepaymentEntity>> = udharDao.getRepaymentsForLoan(loanId)

    suspend fun createUdharLoan(
        personId: Long,
        type: String,
        principalPaise: Long,
        dateTimestamp: Long,
        dueDateTimestamp: Long?,
        linkedAccountId: Long?,
        description: String
    ): Long {
        require(principalPaise > 0) { "Principal must be strictly positive" }
        return database.withTransaction {
            linkedAccountId?.let { accId ->
                when (type) {
                    "LENT" -> accountDao.updateBalance(accId, -principalPaise)
                    "BORROWED" -> accountDao.updateBalance(accId, principalPaise)
                }
            }

            val status = if (dueDateTimestamp != null && dueDateTimestamp < System.currentTimeMillis()) {
                "OVERDUE"
            } else {
                "ACTIVE"
            }

            val loan = UdharLoanEntity(
                personId = personId,
                type = type,
                principalPaise = principalPaise,
                outstandingPaise = principalPaise,
                dateTimestamp = dateTimestamp,
                dueDateTimestamp = dueDateTimestamp,
                linkedAccountId = linkedAccountId,
                description = description,
                status = status
            )
            udharDao.insertLoan(loan)
        }
    }

    suspend fun recordUdharRepayment(
        loanId: Long,
        amountPaise: Long,
        repaymentDateTimestamp: Long = System.currentTimeMillis(),
        linkedAccountId: Long? = null,
        notes: String? = null
    ): Long {
        require(amountPaise > 0) { "Repayment amount must be positive" }
        return database.withTransaction {
            val loan = udharDao.getLoanById(loanId) ?: throw IllegalArgumentException("Loan record not found")
            require(amountPaise <= loan.outstandingPaise) {
                "Repayment amount cannot exceed remaining outstanding amount"
            }

            linkedAccountId?.let { accId ->
                when (loan.type) {
                    "LENT" -> accountDao.updateBalance(accId, amountPaise)
                    "BORROWED" -> accountDao.updateBalance(accId, -amountPaise)
                }
            }

            val newOutstanding = loan.outstandingPaise - amountPaise
            val newStatus = when {
                newOutstanding == 0L -> "FULLY_REPAID"
                loan.dueDateTimestamp != null && loan.dueDateTimestamp < System.currentTimeMillis() -> "OVERDUE"
                else -> "PARTIALLY_REPAID"
            }

            udharDao.updateLoan(
                loan.copy(
                    outstandingPaise = newOutstanding,
                    status = newStatus
                )
            )

            val repayment = UdharRepaymentEntity(
                loanId = loanId,
                personId = loan.personId,
                amountPaise = amountPaise,
                repaymentDateTimestamp = repaymentDateTimestamp,
                linkedAccountId = linkedAccountId,
                notes = notes
            )
            udharDao.insertRepayment(repayment)
        }
    }

    suspend fun deleteLoanSafe(loanId: Long) {
        database.withTransaction {
            val loan = udharDao.getLoanById(loanId) ?: return@withTransaction
            loan.linkedAccountId?.let { accId ->
                when (loan.type) {
                    "LENT" -> accountDao.updateBalance(accId, loan.principalPaise)
                    "BORROWED" -> accountDao.updateBalance(accId, -loan.principalPaise)
                }
            }
            udharDao.deleteLoan(loan)
        }
    }
}
