package com.tuneymanger.app.data.database.dao

import androidx.room.*
import com.tuneymanger.app.data.database.entities.AccountEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface AccountDao {
    @Query("SELECT * FROM accounts WHERE isArchived = 0 ORDER BY name ASC")
    fun getAllActiveAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts ORDER BY isArchived ASC, name ASC")
    fun getAllAccounts(): Flow<List<AccountEntity>>

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    suspend fun getAccountById(id: Long): AccountEntity?

    @Query("SELECT * FROM accounts WHERE id = :id LIMIT 1")
    fun getAccountFlowById(id: Long): Flow<AccountEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAccount(account: AccountEntity): Long

    @Update
    suspend fun updateAccount(account: AccountEntity)

    @Query("UPDATE accounts SET currentBalancePaise = currentBalancePaise + :deltaPaise, updatedAt = :timestamp WHERE id = :accountId")
    suspend fun updateBalance(accountId: Long, deltaPaise: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE accounts SET isArchived = 1, updatedAt = :timestamp WHERE id = :accountId")
    suspend fun archiveAccount(accountId: Long, timestamp: Long = System.currentTimeMillis())

    @Delete
    suspend fun deleteAccount(account: AccountEntity)

    @Query("SELECT COUNT(*) FROM transactions WHERE accountId = :accountId OR destinationAccountId = :accountId")
    suspend fun getTransactionCountForAccount(accountId: Long): Int
}
