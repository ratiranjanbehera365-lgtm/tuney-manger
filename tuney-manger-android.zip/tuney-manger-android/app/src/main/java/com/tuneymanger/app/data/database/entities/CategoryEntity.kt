package com.tuneymanger.app.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "categories")
data class CategoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // EXPENSE or INCOME
    val iconName: String = "category",
    val colorHex: String = "#3B82F6",
    val monthlyBudgetPaise: Long = 0L,
    val isDefault: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
