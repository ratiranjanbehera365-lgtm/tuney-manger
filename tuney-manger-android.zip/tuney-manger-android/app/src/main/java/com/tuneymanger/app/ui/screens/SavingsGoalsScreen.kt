package com.tuneymanger.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuneymanger.app.data.database.entities.SavingsGoalEntity
import com.tuneymanger.app.ui.components.EmptyState
import com.tuneymanger.app.ui.viewmodel.FinanceViewModel
import com.tuneymanger.app.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavingsGoalsScreen(viewModel: FinanceViewModel) {
    val goals by viewModel.activeSavingsGoals.collectAsState()
    val accounts by viewModel.activeAccounts.collectAsState()

    var showAddGoalDialog by remember { mutableStateOf(false) }
    var selectedGoalForContrib by remember { mutableStateOf<SavingsGoalEntity?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Savings Goals", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { showAddGoalDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                icon = { Icon(Icons.Default.Add, contentDescription = null) },
                text = { Text("New Goal") }
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            if (goals.isEmpty()) {
                item {
                    EmptyState(
                        message = "No savings goals created yet",
                        hint = "Create targets like Emergency Fund, Travel, Gadgets, etc."
                    )
                }
            } else {
                items(goals, key = { it.id }) { goal ->
                    val progress = if (goal.targetAmountPaise > 0) {
                        (goal.currentSavedPaise.toFloat() / goal.targetAmountPaise.toFloat()).coerceIn(0f, 1f)
                    } else 0f
                    val percent = (progress * 100).toInt()

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(goal.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("$percent%", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                            }
                            Spacer(modifier = Modifier.height(10.dp))
                            LinearProgressIndicator(
                                progress = { progress },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(CircleShape)
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Saved: ${CurrencyFormatter.formatPaiseToInr(goal.currentSavedPaise)}", style = MaterialTheme.typography.bodySmall)
                                Text("Target: ${CurrencyFormatter.formatPaiseToInr(goal.targetAmountPaise)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                Button(
                                    onClick = { selectedGoalForContrib = goal },
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add Funds")
                                }
                            }
                        }
                    }
                }
            }
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }

    if (showAddGoalDialog) {
        AddGoalDialog(
            onDismiss = { showAddGoalDialog = false },
            onConfirm = { name, targetPaise, desc ->
                viewModel.addSavingsGoal(name, targetPaise, null, desc)
                showAddGoalDialog = false
            }
        )
    }

    selectedGoalForContrib?.let { goal ->
        AddContributionDialog(
            goal = goal,
            accounts = accounts,
            onDismiss = { selectedGoalForContrib = null },
            onConfirm = { amountPaise, accId, notes ->
                viewModel.addSavingsContribution(goal.id, accId, amountPaise, notes)
                selectedGoalForContrib = null
            }
        )
    }
}

@Composable
fun AddGoalDialog(
    onDismiss: () -> Unit,
    onConfirm: (name: String, targetPaise: Long, desc: String?) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var targetInput by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Create Savings Goal") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Goal Name (e.g. Emergency Fund) *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = targetInput, onValueChange = { targetInput = it }, label = { Text("Target Amount in ₹ *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = desc, onValueChange = { desc = it }, label = { Text("Description (optional)") }, modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paise = CurrencyFormatter.parseInputToPaise(targetInput)
                    if (name.isNotBlank() && paise > 0) {
                        onConfirm(name.trim(), paise, desc.trim().ifBlank { null })
                    }
                },
                enabled = name.isNotBlank() && targetInput.isNotBlank()
            ) {
                Text("Create")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun AddContributionDialog(
    goal: SavingsGoalEntity,
    accounts: List<com.tuneymanger.app.data.database.entities.AccountEntity>,
    onDismiss: () -> Unit,
    onConfirm: (amountPaise: Long, accountId: Long?, notes: String?) -> Unit
) {
    var amountInput by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var selectedAccIndex by remember { mutableIntStateOf(0) }
    var linkAccount by remember { mutableStateOf(accounts.isNotEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Contribute to ${goal.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = amountInput, onValueChange = { amountInput = it }, label = { Text("Contribution in ₹ *") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = notes, onValueChange = { notes = it }, label = { Text("Notes (optional)") }, modifier = Modifier.fillMaxWidth())
                if (accounts.isNotEmpty()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(checked = linkAccount, onCheckedChange = { linkAccount = it })
                        Text("Deduct from: ${accounts.getOrNull(selectedAccIndex)?.name ?: ""}", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paise = CurrencyFormatter.parseInputToPaise(amountInput)
                    if (paise > 0) {
                        val accId = if (linkAccount && accounts.isNotEmpty()) accounts[selectedAccIndex].id else null
                        onConfirm(paise, accId, notes)
                    }
                },
                enabled = amountInput.isNotBlank()
            ) {
                Text("Add")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
