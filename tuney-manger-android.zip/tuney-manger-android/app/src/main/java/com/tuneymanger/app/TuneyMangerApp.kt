package com.tuneymanger.app

import android.app.Application

class TuneyMangerApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
