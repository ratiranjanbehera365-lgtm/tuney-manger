package com.tuneymanger.app.data.database.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "accounts")
data class AccountEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val type: String, // CASH, SAVINGS_BANK, CURRENT_BANK, CREDIT_CARD, WALLET, OTHER
    val openingBalancePaise: Long,
    val currentBalancePaise: Long,
    val bankName: String? = null,
    val lastFourDigits: String? = null,
    val colorHex: String = "#10B981",
    val isArchived: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
