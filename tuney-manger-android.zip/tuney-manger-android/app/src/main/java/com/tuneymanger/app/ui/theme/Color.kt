package com.tuneymanger.app.ui.theme

import androidx.compose.ui.graphics.Color

val Emerald800 = Color(0xFF065F46)
val Emerald600 = Color(0xFF059669)
val Emerald500 = Color(0xFF10B981)
val Emerald400 = Color(0xFF34D399)

val Slate900 = Color(0xFF0F172A)
val Slate800 = Color(0xFF1E293B)
val Slate700 = Color(0xFF334155)
val Slate600 = Color(0xFF475569)
val Slate200 = Color(0xFFE2E8F0)
val Slate100 = Color(0xFFF1F5F9)
val Slate50 = Color(0xFFF8FAFC)

val Red500 = Color(0xFFEF4444)
val Amber500 = Color(0xFFF59E0B)
val Blue500 = Color(0xFF3B82F6)
val Purple500 = Color(0xFF8B5CF6)
