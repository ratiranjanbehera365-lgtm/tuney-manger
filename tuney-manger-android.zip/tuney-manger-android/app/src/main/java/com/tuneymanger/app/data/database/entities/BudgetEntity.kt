package com.tuneymanger.app.data.database.entities

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "budgets",
    indices = [Index(value = ["yearMonth", "categoryId"], unique = true)]
)
data class BudgetEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val yearMonth: String,
    val categoryId: Long? = null,
    val limitPaise: Long,
    val alertThresholdPercent: Int = 80,
    val createdAt: Long = System.currentTimeMillis()
)
