package com.tuneymanger.app.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tuneymanger.app.data.database.entities.AccountEntity
import com.tuneymanger.app.data.database.entities.CategoryEntity
import com.tuneymanger.app.util.CurrencyFormatter

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddTransactionDialog(
    accounts: List<AccountEntity>,
    categories: List<CategoryEntity>,
    onDismiss: () -> Unit,
    onConfirm: (
        type: String,
        amountPaise: Long,
        accountId: Long,
        destinationAccountId: Long?,
        categoryId: Long?,
        categoryName: String,
        dateTimestamp: Long,
        paymentMethod: String,
        description: String,
        notes: String?
    ) -> Unit
) {
    var type by remember { mutableStateOf("EXPENSE") }
    var amountInput by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var selectedAccIndex by remember { mutableIntStateOf(0) }
    var selectedDestAccIndex by remember { mutableIntStateOf(if (accounts.size > 1) 1 else 0) }
    var selectedCatIndex by remember { mutableIntStateOf(0) }
    var paymentMethod by remember { mutableStateOf("UPI") }
    var notes by remember { mutableStateOf("") }

    val relevantCategories = remember(categories, type) {
        categories.filter { it.type == type }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Transaction") },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    listOf("EXPENSE", "INCOME", "TRANSFER").forEach { t ->
                        FilterChip(
                            selected = type == t,
                            onClick = { type = t },
                            label = { Text(t.lowercase().replaceFirstChar { it.uppercase() }) }
                        )
                    }
                }

                OutlinedTextField(
                    value = amountInput,
                    onValueChange = { amountInput = it },
                    label = { Text("Amount in ₹ *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    label = { Text("Description / Merchant *") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                if (type == "TRANSFER") {
                    Text("From Account:", style = MaterialTheme.typography.labelMedium)
                    if (accounts.isNotEmpty()) {
                        Text(accounts[selectedAccIndex.coerceIn(0, accounts.size - 1)].name)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("To Account:", style = MaterialTheme.typography.labelMedium)
                    if (accounts.size > 1) {
                        Text(accounts[selectedDestAccIndex.coerceIn(0, accounts.size - 1)].name)
                    }
                } else {
                    Text("Account: ${accounts.getOrNull(selectedAccIndex)?.name ?: "No account"}", style = MaterialTheme.typography.labelMedium)
                    if (relevantCategories.isNotEmpty()) {
                        Text("Category: ${relevantCategories.getOrNull(selectedCatIndex)?.name ?: "General"}", style = MaterialTheme.typography.labelMedium)
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Notes (optional)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val paise = CurrencyFormatter.parseInputToPaise(amountInput)
                    if (paise > 0 && accounts.isNotEmpty()) {
                        val sourceAcc = accounts[selectedAccIndex.coerceIn(0, accounts.size - 1)]
                        val destAcc = if (type == "TRANSFER" && accounts.size > 1) accounts[selectedDestAccIndex.coerceIn(0, accounts.size - 1)] else null
                        val cat = relevantCategories.getOrNull(selectedCatIndex)

                        onConfirm(
                            type,
                            paise,
                            sourceAcc.id,
                            destAcc?.id,
                            cat?.id,
                            cat?.name ?: if (type == "TRANSFER") "Transfer" else "General",
                            System.currentTimeMillis(),
                            paymentMethod,
                            description.trim().ifBlank { cat?.name ?: "Transaction" },
                            notes.trim().ifBlank { null }
                        )
                    }
                },
                enabled = amountInput.isNotBlank() && accounts.isNotEmpty()
            ) {
                Text("Save")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
