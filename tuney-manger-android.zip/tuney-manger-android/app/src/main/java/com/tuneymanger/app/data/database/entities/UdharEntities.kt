package com.tuneymanger.app.data.database.entities

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "udhar_persons")
data class UdharPersonEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phoneNumber: String? = null,
    val relationship: String? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "udhar_loans",
    foreignKeys = [
        ForeignKey(
            entity = UdharPersonEntity::class,
            parentColumns = ["id"],
            childColumns = ["personId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("personId"), Index("type"), Index("status")]
)
data class UdharLoanEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val personId: Long,
    val type: String, // LENT (Money Lent - Receivable) or BORROWED (Money Borrowed - Payable)
    val principalPaise: Long,
    val outstandingPaise: Long,
    val dateTimestamp: Long,
    val dueDateTimestamp: Long? = null,
    val linkedAccountId: Long? = null,
    val description: String,
    val status: String = "ACTIVE", // ACTIVE, PARTIALLY_REPAID, FULLY_REPAID, OVERDUE
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "udhar_repayments",
    foreignKeys = [
        ForeignKey(
            entity = UdharLoanEntity::class,
            parentColumns = ["id"],
            childColumns = ["loanId"],
            onDelete = ForeignKey.RESTRICT
        )
    ],
    indices = [Index("loanId"), Index("personId")]
)
data class UdharRepaymentEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val loanId: Long,
    val personId: Long,
    val amountPaise: Long,
    val repaymentDateTimestamp: Long = System.currentTimeMillis(),
    val linkedAccountId: Long? = null,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)
