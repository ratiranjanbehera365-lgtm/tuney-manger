package com.tuneymanger.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.tuneymanger.app.ui.components.EmptyState
import com.tuneymanger.app.ui.viewmodel.FinanceViewModel
import com.tuneymanger.app.util.CurrencyFormatter
import java.text.SimpleDateFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsScreen(viewModel: FinanceViewModel) {
    val income by viewModel.currentMonthIncomePaise.collectAsState()
    val expense by viewModel.currentMonthExpensePaise.collectAsState()
    val savings by viewModel.currentMonthSavingsPaise.collectAsState()
    val categorySpending by viewModel.currentMonthCategorySpending.collectAsState()
    val totalBalance by viewModel.totalAccountBalancePaise.collectAsState()
    val portfolioValuation by viewModel.totalPortfolioValuationPaise.collectAsState()
    val totalReceivable by viewModel.totalReceivablePaise.collectAsState()
    val totalPayable by viewModel.totalPayablePaise.collectAsState()

    val netWorthPaise = totalBalance + portfolioValuation + totalReceivable - totalPayable

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Reports & Analytics", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Text("Total Estimated Net Worth", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(
                            text = CurrencyFormatter.formatPaiseToInr(netWorthPaise),
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Liquid: ${CurrencyFormatter.formatPaiseToInr(totalBalance)} • Investments: ${CurrencyFormatter.formatPaiseToInr(portfolioValuation)} • Udhar: +${CurrencyFormatter.formatPaiseToInr(totalReceivable)} / -${CurrencyFormatter.formatPaiseToInr(totalPayable)}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text("Monthly Cash Flow", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Income", style = MaterialTheme.typography.bodyMedium)
                            Text(CurrencyFormatter.formatPaiseToInr(income), color = Color(0xFF10B981), fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Total Expenses", style = MaterialTheme.typography.bodyMedium)
                            Text(CurrencyFormatter.formatPaiseToInr(expense), color = Color(0xFFEF4444), fontWeight = FontWeight.Bold)
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Net Surplus / Deficit", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                            val col = if (savings >= 0) Color(0xFF10B981) else Color(0xFFEF4444)
                            Text(CurrencyFormatter.formatPaiseToInr(savings), color = col, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Text("Category Spending Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            }

            if (categorySpending.isEmpty()) {
                item {
                    EmptyState(message = "No expense transactions for this month yet")
                }
            } else {
                items(categorySpending) { item ->
                    val ratio = if (expense > 0) (item.totalPaise.toFloat() / expense.toFloat()) else 0f
                    val percent = (ratio * 100).toInt()

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text(item.categoryName, fontWeight = FontWeight.SemiBold)
                                Text("${CurrencyFormatter.formatPaiseToInr(item.totalPaise)} ($percent%)", fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = { ratio },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(CircleShape)
                            )
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}
