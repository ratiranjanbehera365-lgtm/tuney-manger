package com.tuneymanger.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tuneymanger.app.data.backup.BackupManager
import com.tuneymanger.app.data.database.TuneyDatabase
import com.tuneymanger.app.data.database.entities.*
import com.tuneymanger.app.data.repository.FinanceRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class FinanceViewModel(application: Application) : AndroidViewModel(application) {

    private val database = TuneyDatabase.getDatabase(application, viewModelScope)
    val repository = FinanceRepository(database)
    val backupManager = BackupManager(database)

    private val _themeMode = MutableStateFlow("SYSTEM")
    val themeMode: StateFlow<String> = _themeMode.asStateFlow()

    fun setThemeMode(mode: String) {
        _themeMode.value = mode
    }

    private val _selectedCalendar = MutableStateFlow(Calendar.getInstance())
    val selectedCalendar: StateFlow<Calendar> = _selectedCalendar.asStateFlow()

    val currentMonthRange = _selectedCalendar.map { cal ->
        val start = cal.clone() as Calendar
        start.set(Calendar.DAY_OF_MONTH, 1)
        start.set(Calendar.HOUR_OF_DAY, 0)
        start.set(Calendar.MINUTE, 0)
        start.set(Calendar.SECOND, 0)
        start.set(Calendar.MILLISECOND, 0)

        val end = cal.clone() as Calendar
        end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
        end.set(Calendar.HOUR_OF_DAY, 23)
        end.set(Calendar.MINUTE, 59)
        end.set(Calendar.SECOND, 59)
        end.set(Calendar.MILLISECOND, 999)

        Pair(start.timeInMillis, end.timeInMillis)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, Pair(0L, 0L))

    fun changeMonth(offset: Int) {
        val newCal = _selectedCalendar.value.clone() as Calendar
        newCal.add(Calendar.MONTH, offset)
        _selectedCalendar.value = newCal
    }

    val activeAccounts = repository.getAllActiveAccounts()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalAccountBalancePaise = activeAccounts.map { list ->
        list.sumOf { it.currentBalancePaise }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentMonthIncomePaise = currentMonthRange.flatMapLatest { (start, end) ->
        repository.getTotalIncomePaiseInRange(start, end)
    }.map { it ?: 0L }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentMonthExpensePaise = currentMonthRange.flatMapLatest { (start, end) ->
        repository.getTotalExpensePaiseInRange(start, end)
    }.map { it ?: 0L }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentMonthSavingsPaise = combine(currentMonthIncomePaise, currentMonthExpensePaise) { inc, exp ->
        inc - exp
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val currentMonthCategorySpending = currentMonthRange.flatMapLatest { (start, end) ->
        repository.getCategoryExpenseSummary(start, end)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentTransactions = repository.getRecentTransactions(8)
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions = repository.getAllTransactions()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allCategories = repository.getAllCategories()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentYearMonthStr = _selectedCalendar.map { cal ->
        SimpleDateFormat("yyyy-MM", Locale.getDefault()).format(cal.time)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, "2026-11")

    val currentOverallBudget = currentYearMonthStr.flatMapLatest { ym ->
        repository.getOverallBudgetForMonth(ym)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val activeSavingsGoals = repository.getAllActiveGoals()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val investments = repository.getAllInvestments()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalInvestedPaise = repository.getTotalInvestedPaise().map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalPortfolioValuationPaise = repository.getTotalPortfolioValuationPaise().map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalRealizedProfitLossPaise = repository.getTotalRealizedProfitLossPaise().map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val udharPersons = repository.getAllPersons()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val udharLoans = repository.getAllLoans()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val totalReceivablePaise = repository.getTotalReceivablePaise().map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    val totalPayablePaise = repository.getTotalPayablePaise().map { it ?: 0L }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0L)

    private val _userMessage = MutableSharedFlow<String>()
    val userMessage: SharedFlow<String> = _userMessage.asSharedFlow()

    fun showMessage(msg: String) {
        viewModelScope.launch { _userMessage.emit(msg) }
    }

    fun addTransaction(
        type: String,
        amountPaise: Long,
        accountId: Long,
        destinationAccountId: Long?,
        categoryId: Long?,
        categoryName: String,
        dateTimestamp: Long,
        paymentMethod: String,
        description: String,
        payee: String?,
        notes: String?
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val tx = TransactionEntity(
                    type = type,
                    amountPaise = amountPaise,
                    accountId = accountId,
                    destinationAccountId = destinationAccountId,
                    categoryId = categoryId,
                    categoryName = categoryName,
                    dateTimestamp = dateTimestamp,
                    paymentMethod = paymentMethod,
                    payeeOrMerchant = payee,
                    description = description,
                    notes = notes
                )
                repository.createTransaction(tx)
                showMessage("Transaction recorded successfully!")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun deleteTransaction(transactionId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteTransaction(transactionId)
                showMessage("Transaction deleted & balances updated.")
            } catch (e: Exception) {
                showMessage("Error deleting transaction: ${e.localizedMessage}")
            }
        }
    }

    fun addAccount(name: String, type: String, openingBalancePaise: Long, bankName: String?, colorHex: String) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.createAccount(name, type, openingBalancePaise, bankName, null, colorHex)
                showMessage("Account '$name' created.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun setOverallMonthlyBudget(limitPaise: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val ym = currentYearMonthStr.value
                val budget = BudgetEntity(yearMonth = ym, categoryId = null, limitPaise = limitPaise)
                repository.setBudget(budget)
                showMessage("Monthly budget updated to ₹${limitPaise / 100}")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun addSavingsGoal(name: String, targetAmountPaise: Long, targetDate: Long?, description: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val goal = SavingsGoalEntity(
                    name = name,
                    targetAmountPaise = targetAmountPaise,
                    targetDate = targetDate,
                    description = description
                )
                repository.insertGoal(goal)
                showMessage("Goal '$name' created.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun addSavingsContribution(goalId: Long, accountId: Long?, amountPaise: Long, notes: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.addSavingsContribution(goalId, accountId, amountPaise, notes)
                showMessage("Contribution added successfully!")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun addInvestment(
        name: String,
        category: String,
        quantity: Double,
        pricePerUnitPaise: Long,
        totalInvestedPaise: Long,
        broker: String?,
        linkedAccountId: Long?
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.addInvestment(name, category, quantity, pricePerUnitPaise, totalInvestedPaise, broker, null, linkedAccountId)
                showMessage("Investment '$name' added.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun updateInvestmentPrice(investmentId: Long, newPricePaise: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.updateInvestmentValuation(investmentId, newPricePaise)
                showMessage("Valuation updated.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun addUdharPerson(name: String, phone: String?, relation: String?, notes: String?) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.insertPerson(name, phone, relation, notes)
                showMessage("Contact '$name' added to Udhar Manager.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun createUdharLoan(
        personId: Long,
        type: String,
        principalPaise: Long,
        dateTimestamp: Long,
        dueDateTimestamp: Long?,
        linkedAccountId: Long?,
        description: String
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.createUdharLoan(personId, type, principalPaise, dateTimestamp, dueDateTimestamp, linkedAccountId, description)
                val label = if (type == "LENT") "Money lent" else "Money borrowed"
                showMessage("$label recorded successfully.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun recordUdharRepayment(
        loanId: Long,
        amountPaise: Long,
        linkedAccountId: Long?,
        notes: String?
    ) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.recordUdharRepayment(loanId, amountPaise, System.currentTimeMillis(), linkedAccountId, notes)
                showMessage("Repayment of ₹${amountPaise / 100} recorded.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }

    fun deleteLoan(loanId: Long) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                repository.deleteLoanSafe(loanId)
                showMessage("Loan deleted & balance reverted.")
            } catch (e: Exception) {
                showMessage("Error: ${e.localizedMessage}")
            }
        }
    }
}
