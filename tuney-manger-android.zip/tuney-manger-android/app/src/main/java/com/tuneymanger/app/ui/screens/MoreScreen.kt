package com.tuneymanger.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.tuneymanger.app.ui.navigation.Screen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MoreScreen(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("More Features", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            item {
                MoreMenuItem(
                    title = "Accounts & Wallets",
                    subtitle = "Manage bank accounts, cash, and balances",
                    icon = Icons.Default.AccountBalance,
                    tint = Color(0xFF3B82F6)
                ) {
                    navController.navigate(Screen.Accounts.route)
                }
            }

            item {
                MoreMenuItem(
                    title = "Monthly Budgets",
                    subtitle = "Set expense spending limits and monitor alerts",
                    icon = Icons.Default.PieChart,
                    tint = Color(0xFF10B981)
                ) {
                    navController.navigate(Screen.Budgets.route)
                }
            }

            item {
                MoreMenuItem(
                    title = "Savings Goals",
                    subtitle = "Track financial targets and add contributions",
                    icon = Icons.Default.Savings,
                    tint = Color(0xFF8B5CF6)
                ) {
                    navController.navigate(Screen.SavingsGoals.route)
                }
            }

            item {
                MoreMenuItem(
                    title = "Reports & Analytics",
                    subtitle = "Cash flow, category breakdown, and net worth",
                    icon = Icons.Default.BarChart,
                    tint = Color(0xFFF59E0B)
                ) {
                    navController.navigate(Screen.Reports.route)
                }
            }

            item {
                MoreMenuItem(
                    title = "Backup & Restore",
                    subtitle = "Export or restore offline JSON backups",
                    icon = Icons.Default.CloudSync,
                    tint = Color(0xFF06B6D4)
                ) {
                    navController.navigate(Screen.BackupRestore.route)
                }
            }

            item {
                MoreMenuItem(
                    title = "Settings & Privacy",
                    subtitle = "Theme, Indian currency, and privacy policy",
                    icon = Icons.Default.Settings,
                    tint = Color(0xFF64748B)
                ) {
                    navController.navigate(Screen.Settings.route)
                }
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun MoreMenuItem(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(28.dp))
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Icon(Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
