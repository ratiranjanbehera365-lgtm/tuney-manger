package com.tuneymanger.app.data.database.dao

import androidx.room.*
import com.tuneymanger.app.data.database.entities.UdharLoanEntity
import com.tuneymanger.app.data.database.entities.UdharPersonEntity
import com.tuneymanger.app.data.database.entities.UdharRepaymentEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UdharDao {
    @Query("SELECT * FROM udhar_persons ORDER BY name ASC")
    fun getAllPersons(): Flow<List<UdharPersonEntity>>

    @Query("SELECT * FROM udhar_persons WHERE id = :id LIMIT 1")
    suspend fun getPersonById(id: Long): UdharPersonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPerson(person: UdharPersonEntity): Long

    @Update
    suspend fun updatePerson(person: UdharPersonEntity)

    @Delete
    suspend fun deletePerson(person: UdharPersonEntity)

    @Query("SELECT * FROM udhar_loans ORDER BY dateTimestamp DESC")
    fun getAllLoans(): Flow<List<UdharLoanEntity>>

    @Query("SELECT * FROM udhar_loans WHERE type = :type ORDER BY dateTimestamp DESC")
    fun getLoansByType(type: String): Flow<List<UdharLoanEntity>>

    @Query("SELECT * FROM udhar_loans WHERE personId = :personId ORDER BY dateTimestamp DESC")
    fun getLoansForPerson(personId: Long): Flow<List<UdharLoanEntity>>

    @Query("SELECT * FROM udhar_loans WHERE id = :id LIMIT 1")
    suspend fun getLoanById(id: Long): UdharLoanEntity?

    @Query("SELECT SUM(outstandingPaise) FROM udhar_loans WHERE type = 'LENT' AND status != 'FULLY_REPAID'")
    fun getTotalReceivablePaise(): Flow<Long?>

    @Query("SELECT SUM(outstandingPaise) FROM udhar_loans WHERE type = 'BORROWED' AND status != 'FULLY_REPAID'")
    fun getTotalPayablePaise(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLoan(loan: UdharLoanEntity): Long

    @Update
    suspend fun updateLoan(loan: UdharLoanEntity)

    @Delete
    suspend fun deleteLoan(loan: UdharLoanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRepayment(repayment: UdharRepaymentEntity): Long

    @Query("SELECT * FROM udhar_repayments WHERE loanId = :loanId ORDER BY repaymentDateTimestamp DESC")
    fun getRepaymentsForLoan(loanId: Long): Flow<List<UdharRepaymentEntity>>

    @Query("SELECT * FROM udhar_repayments WHERE personId = :personId ORDER BY repaymentDateTimestamp DESC")
    fun getRepaymentsForPerson(personId: Long): Flow<List<UdharRepaymentEntity>>

    @Query("SELECT SUM(amountPaise) FROM udhar_repayments WHERE loanId = :loanId")
    suspend fun getTotalRepaidPaiseForLoan(loanId: Long): Long?

    @Delete
    suspend fun deleteRepayment(repayment: UdharRepaymentEntity)
}
