package com.tuneymanger.app.data.database.dao

import androidx.room.*
import com.tuneymanger.app.data.database.entities.TransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY dateTimestamp DESC, id DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions ORDER BY dateTimestamp DESC, id DESC LIMIT :limit")
    fun getRecentTransactions(limit: Int = 10): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE dateTimestamp >= :startMs AND dateTimestamp <= :endMs ORDER BY dateTimestamp DESC, id DESC")
    fun getTransactionsInRange(startMs: Long, endMs: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE accountId = :accountId OR destinationAccountId = :accountId ORDER BY dateTimestamp DESC")
    fun getTransactionsForAccount(accountId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE categoryId = :categoryId ORDER BY dateTimestamp DESC")
    fun getTransactionsForCategory(categoryId: Long): Flow<List<TransactionEntity>>

    @Query("SELECT * FROM transactions WHERE id = :id LIMIT 1")
    suspend fun getTransactionById(id: Long): TransactionEntity?

    @Query("""
        SELECT SUM(amountPaise) FROM transactions 
        WHERE type = 'INCOME' AND dateTimestamp >= :startMs AND dateTimestamp <= :endMs
    """)
    fun getTotalIncomePaiseInRange(startMs: Long, endMs: Long): Flow<Long?>

    @Query("""
        SELECT SUM(amountPaise) FROM transactions 
        WHERE type = 'EXPENSE' AND dateTimestamp >= :startMs AND dateTimestamp <= :endMs
    """)
    fun getTotalExpensePaiseInRange(startMs: Long, endMs: Long): Flow<Long?>

    @Query("""
        SELECT categoryName, SUM(amountPaise) as totalPaise FROM transactions 
        WHERE type = 'EXPENSE' AND dateTimestamp >= :startMs AND dateTimestamp <= :endMs
        GROUP BY categoryName ORDER BY totalPaise DESC
    """)
    fun getCategoryExpenseSummary(startMs: Long, endMs: Long): Flow<List<CategorySpendingSummary>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Update
    suspend fun updateTransaction(transaction: TransactionEntity)

    @Delete
    suspend fun deleteTransaction(transaction: TransactionEntity)

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransactionById(id: Long)
}

data class CategorySpendingSummary(
    val categoryName: String,
    val totalPaise: Long
)
