package com.tuneymanger.app.data.backup

import androidx.room.withTransaction
import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.tuneymanger.app.data.database.TuneyDatabase
import com.tuneymanger.app.data.database.entities.*
import kotlinx.coroutines.flow.first

data class TuneyBackupPayload(
    val schemaVersion: Int = 1,
    val appName: String = "Tuney Manger",
    val appVersion: String = "1.0.0",
    val exportedAtTimestamp: Long = System.currentTimeMillis(),
    val accounts: List<AccountEntity> = emptyList(),
    val transactions: List<TransactionEntity> = emptyList(),
    val categories: List<CategoryEntity> = emptyList(),
    val budgets: List<BudgetEntity> = emptyList(),
    val savingsGoals: List<SavingsGoalEntity> = emptyList(),
    val savingsContributions: List<SavingsContributionEntity> = emptyList(),
    val investments: List<InvestmentEntity> = emptyList(),
    val investmentTransactions: List<InvestmentTransactionEntity> = emptyList(),
    val udharPersons: List<UdharPersonEntity> = emptyList(),
    val udharLoans: List<UdharLoanEntity> = emptyList(),
    val udharRepayments: List<UdharRepaymentEntity> = emptyList()
)

class BackupManager(private val database: TuneyDatabase) {

    private val gson: Gson = GsonBuilder().setPrettyPrinting().create()

    suspend fun exportBackupJson(): String {
        val payload = TuneyBackupPayload(
            schemaVersion = 1,
            appName = "Tuney Manger",
            appVersion = "1.0.0",
            exportedAtTimestamp = System.currentTimeMillis(),
            accounts = database.accountDao().getAllAccounts().first(),
            transactions = database.transactionDao().getAllTransactions().first(),
            categories = database.categoryDao().getAllCategories().first(),
            budgets = database.budgetDao().getBudgetsForMonth("").first(),
            savingsGoals = database.savingsGoalDao().getAllGoals().first(),
            investments = database.investmentDao().getAllInvestments().first(),
            udharPersons = database.udharDao().getAllPersons().first(),
            udharLoans = database.udharDao().getAllLoans().first()
        )
        return gson.toJson(payload)
    }

    suspend fun restoreBackupJson(jsonString: String): Result<String> {
        return try {
            val payload = gson.fromJson(jsonString, TuneyBackupPayload::class.java)
                ?: return Result.failure(IllegalArgumentException("Invalid or empty backup file format."))

            if (payload.schemaVersion > 1) {
                return Result.failure(IllegalStateException("Backup schema version ${payload.schemaVersion} is newer than supported version 1."))
            }

            database.withTransaction {
                database.clearAllTables()
                payload.categories.forEach { database.categoryDao().insertCategory(it) }
                payload.accounts.forEach { database.accountDao().insertAccount(it) }
                payload.transactions.forEach { database.transactionDao().insertTransaction(it) }
                payload.budgets.forEach { database.budgetDao().insertOrUpdateBudget(it) }
                payload.savingsGoals.forEach { database.savingsGoalDao().insertGoal(it) }
                payload.savingsContributions.forEach { database.savingsGoalDao().insertContribution(it) }
                payload.investments.forEach { database.investmentDao().insertInvestment(it) }
                payload.investmentTransactions.forEach { database.investmentDao().insertInvestmentTransaction(it) }
                payload.udharPersons.forEach { database.udharDao().insertPerson(it) }
                payload.udharLoans.forEach { database.udharDao().insertLoan(it) }
                payload.udharRepayments.forEach { database.udharDao().insertRepayment(it) }
            }

            Result.success("Backup successfully restored! Restored ${payload.transactions.size} transactions, ${payload.accounts.size} accounts, and ${payload.udharLoans.size} udhar records.")
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
