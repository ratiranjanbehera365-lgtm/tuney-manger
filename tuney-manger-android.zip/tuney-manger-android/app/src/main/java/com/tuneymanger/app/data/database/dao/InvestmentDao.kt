package com.tuneymanger.app.data.database.dao

import androidx.room.*
import com.tuneymanger.app.data.database.entities.InvestmentEntity
import com.tuneymanger.app.data.database.entities.InvestmentTransactionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface InvestmentDao {
    @Query("SELECT * FROM investments ORDER BY currentValuationPaise DESC, name ASC")
    fun getAllInvestments(): Flow<List<InvestmentEntity>>

    @Query("SELECT * FROM investments WHERE id = :id LIMIT 1")
    suspend fun getInvestmentById(id: Long): InvestmentEntity?

    @Query("SELECT SUM(totalInvestedPaise) FROM investments")
    fun getTotalInvestedPaise(): Flow<Long?>

    @Query("SELECT SUM(currentValuationPaise) FROM investments")
    fun getTotalPortfolioValuationPaise(): Flow<Long?>

    @Query("SELECT SUM(realizedProfitLossPaise) FROM investments")
    fun getTotalRealizedProfitLossPaise(): Flow<Long?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestment(investment: InvestmentEntity): Long

    @Update
    suspend fun updateInvestment(investment: InvestmentEntity)

    @Delete
    suspend fun deleteInvestment(investment: InvestmentEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvestmentTransaction(tx: InvestmentTransactionEntity): Long

    @Query("SELECT * FROM investment_transactions WHERE investmentId = :investmentId ORDER BY dateTimestamp DESC")
    fun getTransactionsForInvestment(investmentId: Long): Flow<List<InvestmentTransactionEntity>>
}
