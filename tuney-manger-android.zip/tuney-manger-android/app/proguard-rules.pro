-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.room.* *;
}
-keep class com.tuneymanger.app.data.database.entities.** { *; }
-dontwarn com.google.errorprone.annotations.**
